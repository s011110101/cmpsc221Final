/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hongyi
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
public class ScheduleQueries {
    private static Connection connection;
    private static PreparedStatement addSchedule;
    private static PreparedStatement getScheduleByStudent;
    private static PreparedStatement getStudentCount;
    private static PreparedStatement getWaitlistedStudents;
    private static PreparedStatement dropStudentByCourse;
    private static PreparedStatement dropByCourse;
    private static PreparedStatement getSeats;
    private static ResultSet resultSet;
    private static ArrayList<String> updateMessage = new ArrayList<String>();
    
    public static void addScheduleEntry(ScheduleEntry entry){
        connection = DBConnection.getConnection();
        try
        {
            addSchedule = connection.prepareStatement("insert into app.Schedule (Semester, CourseCode, Status, TimeStamp, StudentID) values (?, ?, ?, ?, ?)");
            addSchedule.setString(1, entry.getSemester()); 
            addSchedule.setString(2, entry.getCourseCode());
            addSchedule.setString(3, entry.getStatus());
            addSchedule.setTimestamp(4, entry.getTimestamp());
            addSchedule.setString(5, entry.getStudentID());
            addSchedule.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }

    }
    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID){
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> schedule = new ArrayList<ScheduleEntry>();
        try
        {
            getScheduleByStudent = connection.prepareStatement("select Semester, CourseCode, Status, TimeStamp, StudentID from app.Schedule where studentID = '"+studentID+"' and semester = '"+semester+"'");
            resultSet = getScheduleByStudent.executeQuery();
            
            while(resultSet.next())
            {
                String Semester = resultSet.getString(1);
                String CourseCode = resultSet.getString(2);
                String Status = resultSet.getString(3);
                Timestamp Timestamp = resultSet.getTimestamp(4);
                String StudentID = resultSet.getString(5);
                schedule.add(new ScheduleEntry(Semester,CourseCode, Status, Timestamp, StudentID));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return schedule;
    }
    public static int getScheduledStudentCount(String semester, String courseCode){
        connection = DBConnection.getConnection();
        int count=0;
        try
        {
            getStudentCount = connection.prepareStatement("select count(*) from app.Schedule where courseCode = '"+courseCode+"' and semester = '"+semester+"'");
            resultSet = getStudentCount.executeQuery();
            while(resultSet.next()){
                count = resultSet.getInt(1);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return count;
    }

    public static boolean seatsAvalible(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        int seats=0;
        try
        {
            getSeats = connection.prepareStatement("select Seats from app.ClassEntry where courseCode = '"+courseCode+"'and semester = '"+semester+"'");
            
            resultSet = getSeats.executeQuery();
            while(resultSet.next()){
                seats = resultSet.getInt(1);
            }
            if (getScheduledStudentCount(semester, courseCode)<seats){
                return true;
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return false;
    }
    
    public static ArrayList<ScheduleEntry> getWaitlistedStudentsByClass(String semester, String courseCode){
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> waitlistedEntry = null;

        try {
            getWaitlistedStudents = connection.prepareStatement("SELECT * from app.Schedule where status = W and semester = '"+semester+"' and coursecode = '"+courseCode+"' order by Timestamp");
            resultSet = getWaitlistedStudents.executeQuery();

            if (resultSet.next()) {
                waitlistedEntry.add(new ScheduleEntry(
                        resultSet.getString(1),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getTimestamp(4),
                        resultSet.getString(5)
                        ));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace(); // Consider logging instead
        }
        return waitlistedEntry;
    }
    
    public static void dropStudentScheduleByCourse(String semester, String studentID, String courseCode){
        connection = DBConnection.getConnection();
        try {
            dropStudentByCourse = connection.prepareStatement("Delete from app.schedule where semester = '"+semester+"' and studentid = '"+studentID+"' and coursecode = '"+courseCode+"'");
            dropStudentByCourse.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace(); // Consider logging instead
        }
    }
    
    public static void dropScheduleByCourse(String semester, String courseCode){
        connection = DBConnection.getConnection();
        try {
            dropByCourse = connection.prepareStatement("Delete from app.schedule where semester = '"+semester+"' and coursecode = '"+courseCode+"'");
            dropByCourse.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace(); // Consider logging instead
        }
    }
    
    
    public static void updateScheduleEntry(ScheduleEntry entry){
        dropStudentScheduleByCourse(entry.getSemester(),entry.getStudentID(),entry.getCourseCode());
        StudentEntry student = StudentQueries.getStudent(entry.getStudentID());
        updateMessage.add(student.getFirstName() + " " + student.getLastName() + " " + entry.getStudentID()+" has been dropped from "+entry.getCourseCode());
        if (entry.getStatus() == "S"){
            ArrayList<ScheduleEntry> waitlisted = getWaitlistedStudentsByClass(entry.getSemester(),entry.getCourseCode());
            if (waitlisted != null && waitlisted.size()>0){
                dropStudentScheduleByCourse(
                        waitlisted.get(0).getSemester(),
                        waitlisted.get(0).getStudentID(),
                        waitlisted.get(0).getCourseCode()
                        );
                waitlisted.get(0).setStatus("S");
                addScheduleEntry(waitlisted.get(0));
                student = StudentQueries.getStudent(waitlisted.get(0).getStudentID());
                updateMessage.add(student.getFirstName() + " " + student.getLastName() + " " + entry.getStudentID()+" has been scheduled into "+entry.getCourseCode());
                waitlisted.remove(0);
            }
        }
    }
    
    public static String getMessage(){
        String ans = "";
        if (updateMessage != null){
            for (String message: updateMessage){
                ans+=message+"\n";
            }
            updateMessage.clear();
        }
        return ans;
    }
    
}
