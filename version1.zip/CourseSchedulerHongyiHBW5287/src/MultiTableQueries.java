/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hongyi
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
public class MultiTableQueries {
    private static Connection connection;
    private static PreparedStatement getClass;
    private static PreparedStatement getStudentID;
    private static PreparedStatement getStudentFirstName;
    private static PreparedStatement getStudentLastName;
    private static PreparedStatement getWaitListed;
    //private static PreparedStatement getSemesterList;
    private static ResultSet resultSet;
    public static ArrayList<ClassDescription> getAllClassDescriptions(String semester){
        ArrayList<ClassDescription> classes = new ArrayList<ClassDescription>();
        connection = DBConnection.getConnection();
        try
        {
            getClass = connection.prepareStatement("SELECT app.classentry.coursecode, description, seats from app.classentry, app.courseentry where semester = '"+semester+"' and app.classentry.coursecode = app.courseentry.coursecode order by app.classentry.coursecode");
            resultSet = getClass.executeQuery();
            while(resultSet.next())
            {
                String Coursecode = resultSet.getString(1);
                String Description = resultSet.getString(2);
                int Seats = resultSet.getInt(3);
                classes.add(new ClassDescription(Coursecode,Description,Seats));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return classes;
    }
    public static ArrayList<StudentEntry> getScheduledStudentsByClass(String semester, String courseCode){
        return getStudentsByClass(semester, courseCode, "S");
    }
    
    public static ArrayList<StudentEntry> getWaitlistedStudentsByClass(String semester, String courseCode){
        return getStudentsByClass(semester, courseCode, "W");
    }
    
    public static ArrayList<StudentEntry> getStudentsByClass(String semester, String courseCode, String status){
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();
        try
        {
            getWaitListed = connection.prepareStatement("select app.Schedule.StudentID, FirstName, LastName from app.Schedule, app.StudentEntry where status = '"+status+"' and courseCode = '"+courseCode+"'and semester = '"+semester+"' and app.Schedule.studentID = app.StudentEntry.studentID order by app.schedule.studentID");
            resultSet = getWaitListed.executeQuery();
            while(resultSet.next()){
                String StudentID = resultSet.getString(1);
                String FirstName = resultSet.getString(2);
                String LastName = resultSet.getString(3);
                students.add(new StudentEntry(StudentID,FirstName,LastName));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return students;
    }
}
