/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hm2;

/**
 *
 * @author hongyi
 */
public class CarLoan extends LoanAccount{
    private String vehicleVIN;
    public CarLoan(double amount, double rateAnnual, int monthNum, String VIN){
        super(amount,rateAnnual,monthNum);
        vehicleVIN = VIN;
    }
    @Override
    public String toString(){
        return "Car "+super.toString()+"Vehicle VIN: " + vehicleVIN +"\n\n";
    }
}
