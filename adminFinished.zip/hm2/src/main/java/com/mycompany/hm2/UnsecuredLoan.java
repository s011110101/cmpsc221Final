/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hm2;

/**
 *
 * @author hongyi
 */
public class UnsecuredLoan extends LoanAccount{
    public UnsecuredLoan(double amount, double rateAnnual, int monthNum){
        super(amount, rateAnnual, monthNum);
    }

    @Override
    public String toString() {
        return "Unsecured "+super.toString()+"\n";
    }
}
