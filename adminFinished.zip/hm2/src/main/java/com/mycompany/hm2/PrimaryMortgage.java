/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hm2;

/**
 *
 * @author hongyi
 */
public class PrimaryMortgage extends LoanAccount{
    private double PMIMonthlyAmount;
    private Address Address;
    public PrimaryMortgage(double amount, double rateAnnual, int monthNum, double PMI, Address Address){
        super(amount,rateAnnual,monthNum);
        this.Address = Address;
        PMIMonthlyAmount = PMI;
    }


    @Override
    public String toString() {
        return "Primary Mortgage "+super.toString()+"PMI Monthly Amount: $"+PMIMonthlyAmount+"\nProperty Address:\n"+Address+"\n\n";
    }
}
