/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hm2;

/**
 *
 * @author hongyi
 */
public class LoanAccount {
    private double annualInterestRate;
    private double principal;
    private double monthlyPayment;
    private int months;

    public LoanAccount(double amount, double rateAnnual, int monthNum){
        principal = amount;
        annualInterestRate = rateAnnual/100.0;
        months = monthNum;
    }
    public double calculateMonthlyPayment(){
        double monthlyInterest = annualInterestRate/12;
        monthlyPayment = principal * ( monthlyInterest / (1 - Math.pow(1 + monthlyInterest, -months)));
        return monthlyPayment;
    }

    public double getPrincipal() {
        return principal;
    }
    public double getAnnualInterestRate(){
        return annualInterestRate*100;
    }
    public int getMonths(){
        return months;
    }
    @Override
    public String toString(){
        return "Loan with:\nPrincipal: $" + String.format("%.2f", getPrincipal()) + "\nAnnual Interest Rate: " + String.format("%.2f", getAnnualInterestRate()) + "%\nTerm of Loan in Months: " + getMonths() +"\nMonthly Payment: $" + String.format("%.2f", calculateMonthlyPayment()) + "\n";
    }

}

